import React from 'react';
import '../static/styles_productivityPage.scss';
import EngIcon from '../assets/eng.png'; // Using your existing icon as a placeholder

// --- Mock Data for Employees ---
const mockEmployees = [
  {
    id: 1,
    name: 'Mustafa Alkilani',
    totalHours: 160,
    totalOutput: 320,
    icon: EngIcon // Placeholder icon
  },
  {
    id: 2,
    name: 'Jane Doe',
    totalHours: 152,
    totalOutput: 350,
    icon: EngIcon // Placeholder icon
  },
  {
    id: 3,
    name: 'John Smith',
    totalHours: 168,
    totalOutput: 300,
    icon: EngIcon // Placeholder icon
  },
];

/**
 * A simple, CSS-only mock bar chart
 */
const MockProductivityChart = ({ hours, output }) => {
  // Simple ratio to make heights look reasonable
  const maxVal = Math.max(hours, output) * 1.1;
  const hoursHeight = (hours / maxVal) * 100;
  const outputHeight = (output / maxVal) * 100;

  return (
    <div className="chart-container">
      <div className="chart-wrapper">
        <div className="chart-bar-group">
          <div 
            className="chart-bar hours" 
            style={{ height: `${hoursHeight}%` }}
          ></div>
          <span className="chart-label">Hours</span>
        </div>
        <div className="chart-bar-group">
          <div 
            className="chart-bar output" 
            style={{ height: `${outputHeight}%` }}
          ></div>
          <span className="chart-label">Output</span>
        </div>
      </div>
    </div>
  );
};


/**
 * A single Employee Productivity Card
 */
const EmployeeEfficiencyCard = ({ employee }) => {
  return (
    <div className="employee-card">
      
      {/* --- Left Side: Info --- */}
      <div className="employee-info">
        <div className="user-icon">
          <img src={employee.icon} alt={employee.name} />
        </div>
        <div className="user-details">
          <h2 className="user-name">{employee.name}</h2>
          <div className="user-stats">
            <span>Total Working Hours: <strong>{employee.totalHours}</strong></span>
            <span>Total Output: <strong>{employee.totalOutput}</strong></span>
          </div>
        </div>
      </div>

      {/* --- Right Side: Chart --- */}
      <div className="employee-chart">
        <MockProductivityChart 
          hours={employee.totalHours} 
          output={employee.totalOutput} 
        />
      </div>
    </div>
  );
};


/**
 * The Main Productivity Page Component
 */
const EfficiencyPage = () => {
  return (
    <div className="page-container">
      <main className="main-content">
        <h1 className="productivity-title">EFFICIENCY</h1>
        
        <div className="employee-list-container">
          {mockEmployees.map(employee => (
            <EmployeeEfficiencyCard key={employee.id} employee={employee} />
          ))}
        </div>
      </main>
    </div>
  );
};

export default EfficiencyPage;
